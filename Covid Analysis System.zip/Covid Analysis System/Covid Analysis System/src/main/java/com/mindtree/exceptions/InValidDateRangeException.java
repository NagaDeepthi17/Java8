package com.mindtree.exceptions;

public class InValidDateRangeException extends Exception {
public InValidDateRangeException() {
		
	}
	public InValidDateRangeException(String message) {
		super(message);
	}

}

package com.mindtree.controller;

import java.time.LocalDate;
import java.util.IntSummaryStatistics;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.Map.Entry;
import com.mindtree.exceptions.InValidDateException;
import com.mindtree.exceptions.InValidDateRangeException;
import com.mindtree.exceptions.InvalidStateException;
import com.mindtree.exceptions.NoDataFoundException;
import com.mindtree.service.CovidAnalysisService;


public class CovidAnalysisController {
	private static final CovidAnalysisService covidAnalysisService = new CovidAnalysisService();
	private final Scanner scanner;
	public CovidAnalysisController() {
        scanner = new Scanner(System.in);
    }
	
	public void startApplication() throws NoDataFoundException, InValidDateException, InValidDateRangeException, InvalidStateException{
        int choice;
        do {
            displayMainMenu();
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    getStateNames();
                    break;
                case 2:
                	getDistrictByState();
                	break;
                case 3:
                	getDataByStateWithinDateRange();
                	break;
                case 4:
                	displayConfirmedCasesByStatesAndDateRange();
                	break;
                
                case 5:
                    exit();
                    break;
                default:
                    System.out.println("Invalid choice. Please choose the option between 1to5.");
            }
        } while (choice != 5);
    }

    private void displayMainMenu() {
    	System.out.println();
        System.out.println("*************************************************");
        System.out.println("1. Get state names");
        System.out.println("2. Get district names for a given state");
        System.out.println("3. Display data by state within a date range");
        System.out.println("4. Display Confirmed Cases by comparing two states for a given date range");
        System.out.println("5. Exit");
        System.out.print("Enter your choice: ");
        System.out.println();
    }
//Q1
    private void getStateNames() {
        System.out.println("List of State Names:");
        covidAnalysisService.getStateNames().forEach(System.out::println);
    }
    //Q2
    private void getDistrictByState(){
        System.out.print("Enter state name: ");
        String state = scanner.nextLine();
        try {
        	covidAnalysisService.getDistrictByState(state).forEach(System.out::println);;
        }catch(InvalidStateException e) {
        	System.out.println(e.getMessage());
        }
    }
//Q3
    private void getDataByStateWithinDateRange() throws NoDataFoundException, InValidDateException, InValidDateRangeException{
        System.out.print("Enter start date (YYYY-MM-DD): ");
        LocalDate startDate = LocalDate.parse(scanner.nextLine());
        System.out.print("Enter end date (YYYY-MM-DD): ");
        LocalDate endDate = LocalDate.parse(scanner.nextLine());
        TreeMap<LocalDate, Map<String, IntSummaryStatistics>> withInDateRange=covidAnalysisService.getDataByStateWithInDateRange(startDate, endDate);
		System.out.println("      Date| State| Confirmed total");
		for (Entry<LocalDate, Map<String, IntSummaryStatistics>> entry : withInDateRange.entrySet()) {
			entry.getValue().forEach((k, v) -> {
				System.out.println(entry.getKey() + "|    " + k + "|       " + v.getSum());
			});
		}
		
    }
    //Q4
    private void displayConfirmedCasesByStatesAndDateRange() throws NoDataFoundException, InValidDateException, InValidDateRangeException, InvalidStateException {
    System.out.print("Enter the first state name: ");
    String firstState = scanner.next();
    System.out.print("Enter the second state name: ");
    String secondState = scanner.next();
    System.out.print("Enter the start date (yyyy-mm-dd): ");
    String startDateStr = scanner.next();
    System.out.print("Enter the end date (yyyy-mm-dd): ");
    String endDateStr = scanner.next();

    LocalDate startDate = LocalDate.parse(startDateStr);
    LocalDate endDate = LocalDate.parse(endDateStr);
    TreeMap<LocalDate, Map<String, IntSummaryStatistics>> comparingTwoStatesData = covidAnalysisService
			.getConfirmedCasesByComparingTwoStatesData(startDate, endDate, firstState, secondState);
	System.out.println(
			"DATE       |      FIRST STATE     |     FIRST STATE CONFIRMED TOTAL     |     SECOND STATE     |    SECOND STATE CONFIRMED TOTAL	");
	for (Entry<LocalDate, Map<String, IntSummaryStatistics>> entry : comparingTwoStatesData.entrySet()) {

		System.out.println(entry.getKey() + " |          " + firstState + "          |                 "
				+ entry.getValue().get(firstState).getSum() + "                 |          " + secondState
				+ "          |               " + entry.getValue().get(secondState).getSum());
	}
    
    }
//Q5
    private void exit() {
        System.out.println("Exiting the application. Goodbye!");
    }
    public static void main(String[] args) throws NoDataFoundException, InValidDateException, InValidDateRangeException, InvalidStateException{
        CovidAnalysisController controller = new CovidAnalysisController();
        controller.startApplication();
    }

   
}
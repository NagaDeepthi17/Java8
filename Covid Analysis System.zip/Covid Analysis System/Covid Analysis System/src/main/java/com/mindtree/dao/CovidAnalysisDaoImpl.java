package com.mindtree.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import com.mindtree.entity.CovidAnalysis;

public class CovidAnalysisDaoImpl implements CovidAnalysisDao{
	private static final String URL="jdbc:mysql://localhost:3306/covid_analysis";
	private static final String USER="root";
	private static final String PWD="Deepthi#17";
	
//Q1
	
	@Override
	public List<String> getStateNames() {
		// TODO Auto-generated method stub
		List<String>stateNames=new ArrayList<>();
		try(Connection con=DriverManager.getConnection(URL,USER,PWD);
				Statement statement=con.createStatement();
				ResultSet res=statement.executeQuery("SELECT DISTINCT state FROM covid_data ORDER BY state")
				){
			
			while(res.next()) {
				stateNames.add(res.getString("state"));
			}	
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return stateNames;		
	}
	//Q2
	@Override
	public List<String> getDistrictByState(String state) {
        List<String> districtNames = new ArrayList<>();

        try (Connection connection = DriverManager.getConnection(URL, USER, PWD);
             PreparedStatement statement = connection.prepareStatement("SELECT DISTINCT district FROM covid_data WHERE state = ? ORDER BY district")) {
            statement.setString(1, state);

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    districtNames.add(resultSet.getString("district"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return districtNames;
    }
	
//Q3
	@Override
	public List<CovidAnalysis> getDataByStateWithinDateRange(LocalDate startDate,LocalDate endDate) {
		// TODO Auto-generated method stub
		List<CovidAnalysis>li=new ArrayList<>();
			try (Connection connection = DriverManager.getConnection(URL, USER, PWD);
            PreparedStatement statement = connection.prepareStatement("select * from covid_data")){
           try (ResultSet resultSet = statement.executeQuery()) {
               while (resultSet.next()) {
               	
               	String state1=resultSet.getString("state");
               	int tested=resultSet.getInt("tested");
               	int confirmed=resultSet.getInt("confirmed");
               	int recovered=resultSet.getInt("recovered");
               	LocalDate date1=resultSet.getDate("date").toLocalDate();
               	CovidAnalysis ca=new CovidAnalysis(state1,tested,confirmed,recovered,date1);
               	li.add(ca);
               }
               
           }
           
       } catch (SQLException e) {
           e.printStackTrace();
       }
     return li;	
     
	}
	//Q4
	@Override
    public List<CovidAnalysis> getCovidDataByStateAndDateRange(LocalDate startDate, LocalDate endDate,String fState,String sState) {
        List<CovidAnalysis> covidDataList = new ArrayList<>();
        try {Connection connection = DriverManager.getConnection(URL, USER, PWD);
            PreparedStatement statement = connection.prepareStatement("select * from covid_data");
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                
                String state1 = resultSet.getString("state");
                int confirmed = resultSet.getInt("confirmed");
                LocalDate date=resultSet.getDate("date").toLocalDate();
                CovidAnalysis covidData = new CovidAnalysis(state1,confirmed,date);
                covidDataList.add(covidData);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return covidDataList;
    }

}
package com.mindtree.exceptions;

public class InValidDateException extends Exception {
	
	public InValidDateException() {
		
	}
	public InValidDateException(String message) {
		super(message);
	}

}

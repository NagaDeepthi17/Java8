package com.mindtree.service;

import java.time.LocalDate;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import com.mindtree.dao.CovidAnalysisDaoImpl;
import com.mindtree.entity.CovidAnalysis;
import com.mindtree.exceptions.InValidDateException;
import com.mindtree.exceptions.InValidDateRangeException;
import com.mindtree.exceptions.InvalidStateException;
import com.mindtree.exceptions.NoDataFoundException;


public class CovidAnalysisService {
	CovidAnalysisDaoImpl covidAnalysisDaoImpl=new CovidAnalysisDaoImpl();	
	public CovidAnalysisService() {
	}
	//Q1
	public List<String> getStateNames() {
        return covidAnalysisDaoImpl.getStateNames();
    }
//Q2	
    public List<String> getDistrictByState(String state) throws InvalidStateException{
    	
    	Predicate<List<String>>listNotEmpty=list->list!=null&&!list.isEmpty();
    	List<String>districtNames=covidAnalysisDaoImpl.getDistrictByState(state);
		if(listNotEmpty.test(districtNames)) {
			System.out.println("List of District Names for " + state + ":");
		}
		else {
			throw new InvalidStateException("Invalid State Code,Please check your input");
		}
		return districtNames;
    }

    //Q3

    public TreeMap<LocalDate, Map<String, IntSummaryStatistics>> getDataByStateWithInDateRange(LocalDate startDate,
			LocalDate endDate) throws NoDataFoundException, InValidDateException, InValidDateRangeException {

		Map<LocalDate, Map<String, IntSummaryStatistics>> collect3 = null;
		List<CovidAnalysis> data = covidAnalysisDaoImpl.getDataByStateWithinDateRange(startDate, endDate);
		if (!data.stream().anyMatch(cd -> cd.getDate().isEqual(startDate))) {

			throw new InValidDateException("Invalid Start Date Please Check your input.");
		}

		else if (!data.stream().anyMatch(cd -> cd.getDate().isEqual(endDate))) {
			throw new InValidDateException("Invalid End Date Please Check your input.");
		}
		else if (!startDate.isBefore(endDate)) {
			throw new InValidDateRangeException("Invalid Date Range, check Your Input.");
		}

		else {
			Predicate<CovidAnalysis> predicate = cd -> cd.getDate().isAfter(startDate) && cd.getDate().isBefore(endDate);

			List<CovidAnalysis> collect = data.stream().filter(predicate).collect(Collectors.toList());

			if (collect.isEmpty()) {
				throw new NoDataFoundException("No Data Present.");
			} else {
				collect3 = collect.stream().collect(Collectors.groupingBy(CovidAnalysis::getDate, Collectors
						.groupingBy(CovidAnalysis::getState, Collectors.summarizingInt(CovidAnalysis::getConfirmed))));
			}

		}
		return new TreeMap<LocalDate, Map<String, IntSummaryStatistics>>(collect3);
	}

    
      
    //Q4
    public TreeMap<LocalDate, Map<String, IntSummaryStatistics>> getConfirmedCasesByComparingTwoStatesData(
			LocalDate startDate, LocalDate endDate, String fState, String sState) throws NoDataFoundException, InValidDateException, InValidDateRangeException, InvalidStateException {

		Map<LocalDate, Map<String, IntSummaryStatistics>> collect3 = null;
		List<CovidAnalysis> data = covidAnalysisDaoImpl.getCovidDataByStateAndDateRange(startDate, endDate,fState,sState);
		if (!data.stream().anyMatch(cd -> cd.getDate().isEqual(startDate))) {

			throw new InValidDateException("Invalid Start Date Please Check your input.");
		}

		else if (!data.stream().anyMatch(cd -> cd.getDate().isEqual(endDate))) {
			throw new InValidDateException("Invalid End Date Please Check your input.");
		}
		else if (!startDate.isBefore(endDate)) {
			throw new InValidDateRangeException("Invalid Date Range, check Your Input.");
		}

		else {
			Predicate<CovidAnalysis> predicate = cd -> cd.getState().equals(fState);
			Predicate<CovidAnalysis> predicate1 = cd -> cd.getState().equals(sState);
			boolean fStateMatch = data.stream().anyMatch(predicate);
			boolean sStateMatch = data.stream().anyMatch(predicate1);

			if (!fStateMatch) {
				throw new InvalidStateException("Invalid State code, please check your input");
			} else if (!sStateMatch) {
				throw new InvalidStateException("Invalid State code, please check your input");
			}
			Predicate<CovidAnalysis> datePredicate = cd -> cd.getDate().isAfter(startDate)
					&& cd.getDate().isBefore(endDate);

			Predicate<CovidAnalysis> statePredicate = cd -> cd.getState().equals(fState) || cd.getState().equals(sState);

			List<CovidAnalysis> collect = data.stream().filter(datePredicate.and(statePredicate))
					.collect(Collectors.toList());

			if (collect.isEmpty()) {
				throw new NoDataFoundException("No Data Present.");
			} else {
				collect3 = collect.stream().collect(Collectors.groupingBy(CovidAnalysis::getDate, Collectors
						.groupingBy(CovidAnalysis::getState, Collectors.summarizingInt(CovidAnalysis::getConfirmed))));
			}

		}
		return new TreeMap<LocalDate, Map<String, IntSummaryStatistics>>(collect3);

	}


}
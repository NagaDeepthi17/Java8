package com.mindtree.exceptions;

public class NoDataFoundException extends Exception{
public NoDataFoundException() {
		
	}
	public NoDataFoundException(String message) {
		super(message);
	}

}

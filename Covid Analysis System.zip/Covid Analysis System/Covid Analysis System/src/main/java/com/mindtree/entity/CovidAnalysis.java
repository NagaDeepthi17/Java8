package com.mindtree.entity;
import java.time.LocalDate;
import java.util.Objects;

public class CovidAnalysis implements Comparable<CovidAnalysis> {
	private int id;
	private String state;
	private String district;
	private int tested;
	private int confirmed;
	private int recovered;
	private LocalDate date;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public int getTested() {
		return tested;
	}
	public void setTested(int tested) {
		this.tested = tested;
	}
	public int getConfirmed() {
		return confirmed;
	}
	public void setConfirmed(int confirmed) {
		this.confirmed = confirmed;
	}
	public int getRecovered() {
		return recovered;
	}
	public void setRecovered(int recovered) {
		this.recovered = recovered;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public CovidAnalysis() {
		super();
	}
	public CovidAnalysis(String state, int confirmed, LocalDate date) {
		super();
		this.state = state;
		this.confirmed = confirmed;
		this.date = date;
	}
	public CovidAnalysis(String state, int tested, int confirmed, int recovered, LocalDate date) {
		super();
		this.state = state;
		this.tested = tested;
		this.confirmed = confirmed;
		this.recovered = recovered;
		this.date = date;
	}
	@Override
	public int hashCode() {
		return Objects.hash(confirmed, date, district, id, recovered, state, tested);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CovidAnalysis other = (CovidAnalysis) obj;
		return confirmed == other.confirmed && Objects.equals(date, other.date)
				&& Objects.equals(district, other.district) && id == other.id && recovered == other.recovered
				&& Objects.equals(state, other.state) && tested == other.tested;
	}
	@Override
    public int compareTo(CovidAnalysis other) {
        return this.date.compareTo(other.getDate());
    }
	@Override
	public String toString() {
		return "CovidAnalysis [id=" + id + ", state=" + state + ", district=" + district + ", tested=" + tested
				+ ", confirmed=" + confirmed + ", recovered=" + recovered + ", date=" + date + "]";
	}
}
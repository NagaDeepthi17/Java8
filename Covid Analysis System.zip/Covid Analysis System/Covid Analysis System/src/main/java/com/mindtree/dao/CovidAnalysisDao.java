package com.mindtree.dao;

import java.time.LocalDate;
import java.util.List;
import com.mindtree.entity.CovidAnalysis;
public interface CovidAnalysisDao{
	
	List<String> getStateNames();
	List<String> getDistrictByState(String state);
	List<CovidAnalysis> getDataByStateWithinDateRange(LocalDate startDate,LocalDate endDate);
	List<CovidAnalysis> getCovidDataByStateAndDateRange(LocalDate startDate, LocalDate endDate,String fState,String sState);
	}
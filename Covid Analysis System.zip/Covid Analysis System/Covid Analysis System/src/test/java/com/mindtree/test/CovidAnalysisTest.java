package com.mindtree.test;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import java.time.LocalDate;
import java.time.Month;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.mindtree.exceptions.InvalidStateException;
import com.mindtree.exceptions.InValidDateException;
import com.mindtree.exceptions.InValidDateRangeException;
import com.mindtree.exceptions.NoDataFoundException;
import com.mindtree.service.CovidAnalysisService;

public class CovidAnalysisTest {	
   CovidAnalysisService covidAnalysisService=new CovidAnalysisService();
@Test
@DisplayName("Get State Names")
void testGetStateNames() {
	List<String>stateNames=covidAnalysisService.getStateNames();
	assertEquals(stateNames.size(),35);
	assertTrue(stateNames.containsAll(stateNames));	
}
@Test
@DisplayName("Get District Names By State Name")
void testGetDistrictsForState() throws InvalidStateException{
	List<String>dist=covidAnalysisService.getDistrictByState("ap");
	assertEquals(dist.size(),16);
	assertTrue(dist.containsAll(dist));
}

@Test
@DisplayName("Get Confirmed Cases between Given Date Range")
void confirmedCases() throws NoDataFoundException, InValidDateException, InValidDateRangeException {

	TreeMap<LocalDate, Map<String, IntSummaryStatistics>> dataBySatesWithInDateRange = covidAnalysisService
			.getDataByStateWithInDateRange(LocalDate.of(2020, Month.JUNE, 1), LocalDate.of(2020, Month.AUGUST, 1));

	assertTrue(dataBySatesWithInDateRange.size() > 0);

	assertEquals(dataBySatesWithInDateRange.get(LocalDate.of(2020, 7, 7)).get("UP").getSum(), 1332);
}

@Test
@DisplayName("If given date is invalid throw InvalidDateException")
void confirmedCasesInvalidDateException()
		throws NoDataFoundException, InValidDateException, InValidDateRangeException {

	assertThrows(InValidDateException.class, () -> {
		covidAnalysisService.getDataByStateWithInDateRange(LocalDate.of(2019, Month.AUGUST, 1),
				LocalDate.of(2022, Month.JUNE, 1));
	});
}

@Test
@DisplayName("If given date range is invalid throw InvalidDateRangeException")
void confirmedCasesInvalidDateRangeException()
		throws NoDataFoundException, InValidDateException, InValidDateRangeException {

	assertThrows(InValidDateRangeException.class, () -> {
		covidAnalysisService.getDataByStateWithInDateRange(LocalDate.of(2020, Month.AUGUST, 1),
				LocalDate.of(2020, Month.JUNE, 1));
	});
}

@Test
@DisplayName("If No data is avilable between given date range throw NoDataFoundException")
void confirmedCasesNoDataFoundException()
		throws NoDataFoundException, InValidDateException, InValidDateRangeException {

	assertThrows(InValidDateRangeException.class, () -> {
		covidAnalysisService.getDataByStateWithInDateRange(LocalDate.of(2020, Month.AUGUST, 1),
				LocalDate.of(2020, Month.AUGUST, 1));
	});
}
@Test
@DisplayName("Get Confirmed Cases between Given Date Range and between two states")
void confirmedCasesbetweenTwoStates() throws NoDataFoundException, InValidDateException, InValidDateRangeException, InValidDateException, InvalidStateException {

	TreeMap<LocalDate, Map<String, IntSummaryStatistics>> confirmedCasesByComparingTwoStatesData = covidAnalysisService
			.getConfirmedCasesByComparingTwoStatesData(LocalDate.of(2020, 8, 4), LocalDate.of(2020, 8, 7), "PB",
					"CH");
	assertTrue(confirmedCasesByComparingTwoStatesData.size() > 0);
	assertEquals(confirmedCasesByComparingTwoStatesData.get(LocalDate.of(2020, 8, 6)).get("PB").getSum(), 1035);
	assertEquals(confirmedCasesByComparingTwoStatesData.get(LocalDate.of(2020, 8, 6)).get("CH").getSum(), 57);
}

@Test
@DisplayName("If given date is invalid for confirmedCasesbetweenTwoStates throw InvalidDateException")
void confirmedCasesbetweenTwoStatesInvalidDateException() throws InValidDateException {

	assertThrows(InValidDateException.class, () -> {
		covidAnalysisService.getConfirmedCasesByComparingTwoStatesData(LocalDate.of(2019, 8, 4),
				LocalDate.of(2020, 8, 7), "PB", "CH");
	});
}

@Test()
@DisplayName("If state Code is invalid for confirmedCasesbetweenTwoStates throw InvalidStateCodeException")
void confirmedCasesbetweenTwoStatesInvalidStateCodeException() {

	InvalidStateException assertThrows2 = assertThrows(InvalidStateException.class, () -> {
		covidAnalysisService.getConfirmedCasesByComparingTwoStatesData(LocalDate.of(2020, 8, 4),
				LocalDate.of(2020, 8, 7), "P", "C");
	});

	assertEquals("Invalid State code, please check your input", assertThrows2.getMessage());
}

@Test
@DisplayName("If given date range is invalid for confirmedCasesbetweenTwoStates throw InvalidDateRangeException")
void confirmedCasesbetweenTwoStatesInvalidDateRangeException() throws InValidDateRangeException {

	assertThrows(InValidDateRangeException.class, () -> {
		covidAnalysisService.getConfirmedCasesByComparingTwoStatesData(LocalDate.of(2020, 8, 8),
				LocalDate.of(2020, 8, 4), "PB", "CH");
	});
}

@Test
@DisplayName("If No data is avilable for confirmedCasesbetweenTwoStates given date range then throw NoDataFoundException")
void confirmedCasesbetweenTwoStatesNoDataFoundException() throws NoDataFoundException {

	assertThrows(InValidDateRangeException.class, () -> {
		covidAnalysisService.getConfirmedCasesByComparingTwoStatesData(LocalDate.of(2020, 8, 4),
				LocalDate.of(2020, 8, 4), "PB", "CH");
	});
}




}
